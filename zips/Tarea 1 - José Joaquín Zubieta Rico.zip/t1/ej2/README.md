# Ejercicio 2 : Tarea 1 - Image Compression
### José Joaquín Zubieta Rico (08-30-2018)

**Description**
Ejercicio uno de la primer tarea de compresión de imágenes, verificar si un código es unívocamente decodificable o no.

---

#### Compile Instructions

For compile instructions go to [COMPILE.md](./COMPILE.md) file.

---

**License**: All the code is under the [GPL v3](https://www.gnu.org/licenses/gpl-3.0.en.html) license.
