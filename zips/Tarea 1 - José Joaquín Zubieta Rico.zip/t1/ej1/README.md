# Ejercicio 1 : Tarea 1 - Image Compression
### José Joaquín Zubieta Rico (08-29-2018)

**Description**
Ejercicio uno de la primer tarea de compresión de imágenes, calcular las distribuciones de los caracteres ascii, así como correlaciones hasta 3er orden.

---

#### Compile Instructions

For compile instructions go to [COMPILE.md](./COMPILE.md) file.

---

**License**: All the code is under the [GPL v3](https://www.gnu.org/licenses/gpl-3.0.en.html) license.
